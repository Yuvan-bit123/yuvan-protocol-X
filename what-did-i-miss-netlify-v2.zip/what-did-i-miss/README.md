# What Did I Miss?

Paste a conversation, get a summary, key decisions, open questions and action items with deadlines and priorities.

- Frontend: React + Vite (`src/`)
- Backend: Netlify Function (`netlify/functions/summarize.js`) that calls the Anthropic API
- Secret: `ANTHROPIC_API_KEY` is set only in Netlify environment variables (never in the browser)

## Features
- Calm, editorial design with light/dark theme (follows your system, with a manual toggle)
- Structured summary: summary, key decisions, open questions, urgency and tone tags
- Brief / Detailed summaries and any output language
- Action items: inline edit (task, owner, deadline), add manually, click the priority pill to change it, delete with Undo
- Filters (All / Today / Overdue / High priority / Done), owner filter, sort (priority / deadline / newest), search across tasks and summaries
- Summary history: collapsible cards, linked tasks, original text, copy as Markdown, re-summarize, delete with Undo
- Reminders: configurable lead time (Settings menu), snooze 15 min / 1 hr / tomorrow, browser notifications
- Export: tasks to calendar (.ics), all data to JSON, import JSON
- Dashboard strip: open, due today, overdue, completion ring
- Drag-and-drop or upload a `.txt` / `.md` / `.eml` file
- Keyboard shortcuts: `Ctrl/Cmd+Enter` summarize, `/` search, `N` new task, `?` help
- Installable as an app (PWA manifest and icons)

Data is stored in your browser's localStorage (key `wdim:data:v2`). Data from the previous version (`v1`) is migrated automatically.

## Deploy
1. Push this folder to a GitHub repo.
2. Netlify > Add new site > Import an existing project > pick the repo (settings come from `netlify.toml`).
3. Site configuration > Environment variables > add `ANTHROPIC_API_KEY`.
4. Deploys > Trigger deploy (so the key is picked up).

## Local
`npm install`, then `npx netlify dev` (runs the site and the function together).
