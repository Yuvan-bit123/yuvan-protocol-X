import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { summarize } from "./api";
import { loadSettings, saveSettings } from "./storage";
import { notify, permission, requestPermission } from "./notifications";
import { useTasks } from "./hooks/useTasks";
import { useTheme } from "./hooks/useTheme";
import { useToasts } from "./hooks/useToasts";
import {
  MINUTE,
  copyText,
  deadlineInfo,
  downloadFile,
  isToday,
  itemsToIcs,
  summaryToMarkdown,
  toLocalIso,
  toTime,
} from "./utils";
import Header from "./components/Header";
import Dashboard from "./components/Dashboard";
import Composer, { MAX_CHARS } from "./components/Composer";
import TaskList from "./components/TaskList";
import SummaryCard, { SummarySkeleton } from "./components/SummaryCard";
import EmptyState from "./components/EmptyState";
import Toasts from "./components/Toasts";
import ShortcutsDialog from "./components/ShortcutsDialog";
import Icon from "./components/Icons";

const isTyping = (el) =>
  el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable);

export default function App() {
  const { data, dataRef, setData, addResult, replaceResult, updateItem, addItem, removeItem, removeSummary, importData } =
    useTasks();
  const [settings, setSettings] = useState(loadSettings);
  const settingsRef = useRef(settings);
  const { toasts, toast, dismiss } = useToasts();
  const theme = useTheme(settings.theme, (t) => setSettings((s) => ({ ...s, theme: t })));

  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [alerts, setAlerts] = useState([]); // [{ taskId }]
  const [perm, setPerm] = useState(permission());
  const [query, setQuery] = useState("");
  const [now, setNow] = useState(Date.now());
  const [newId, setNewId] = useState(null);
  const [showKeys, setShowKeys] = useState(false);
  const [installEvt, setInstallEvt] = useState(null);
  const [busyId, setBusyId] = useState(null);

  const textareaRef = useRef(null);
  const searchRef = useRef(null);
  const lastReq = useRef(null);
  const loadingRef = useRef(false);

  const leadMs = settings.leadMinutes * MINUTE;

  useEffect(() => {
    settingsRef.current = settings;
    saveSettings(settings);
  }, [settings]);

  // Tick so relative labels ("Due in 20m") stay fresh.
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(id);
  }, []);

  // Notify when a task is due within the reminder window or overdue.
  // Runs every 30s and right after tasks change, so new tasks alert immediately.
  const checkDeadlines = useCallback(() => {
    const t0 = Date.now();
    const lead = settingsRef.current.leadMinutes * MINUTE;
    const due = dataRef.current.items.filter((it) => {
      if (it.done || it.notified || !it.deadline) return false;
      if (it.snoozedUntil && t0 < it.snoozedUntil) return false;
      const t = toTime(it.deadline);
      return t != null && t - t0 <= lead;
    });
    if (!due.length) return;
    due.forEach((it) => notify("Deadline soon: " + it.task, deadlineInfo(it.deadline, lead, t0).text));
    const ids = new Set(due.map((d) => d.id));
    setAlerts((a) => [...a.filter((x) => !ids.has(x.taskId)), ...due.map((d) => ({ taskId: d.id }))]);
    setData((d) => ({
      ...d,
      items: d.items.map((it) => (ids.has(it.id) ? { ...it, notified: true, snoozedUntil: null } : it)),
    }));
  }, [dataRef, setData]);

  useEffect(() => {
    const id = setInterval(checkDeadlines, 30000);
    return () => clearInterval(id);
  }, [checkDeadlines]);

  useEffect(() => {
    checkDeadlines();
  }, [data.items, settings.leadMinutes, checkDeadlines]);

  // PWA install prompt
  useEffect(() => {
    const on = (e) => {
      e.preventDefault();
      setInstallEvt(e);
    };
    window.addEventListener("beforeinstallprompt", on);
    return () => window.removeEventListener("beforeinstallprompt", on);
  }, []);

  const run = useCallback(
    async (req) => {
      if (loadingRef.current) return;
      loadingRef.current = true;
      lastReq.current = req;
      setLoading(true);
      setBusyId(req.summaryId || null);
      setError("");
      try {
        const result = await summarize(req.text, req.options);
        if (req.summaryId) {
          replaceResult(req.summaryId, result, req.options);
          toast("Summary refreshed");
        } else {
          addResult(result, req.text, req.options);
          setText("");
          toast(
            result.items.length
              ? `Summary ready · ${result.items.length} action item${result.items.length === 1 ? "" : "s"} added`
              : "Summary ready · no action items found"
          );
        }
        lastReq.current = null;
      } catch (e) {
        setError(e.message || "Something went wrong.");
      } finally {
        loadingRef.current = false;
        setLoading(false);
        setBusyId(null);
      }
    },
    [addResult, replaceResult, toast]
  );

  const submit = useCallback(() => {
    const t = text.trim();
    if (!t || t.length > MAX_CHARS) return;
    run({ text: t, options: { length: settings.length, language: settings.language.trim() || "English" } });
  }, [text, settings.length, settings.language, run]);

  const submitRef = useRef(submit);
  submitRef.current = submit;

  const addTask = useCallback(() => {
    const it = addItem({ task: "New task" });
    setNewId(it.id);
  }, [addItem]);
  const addTaskRef = useRef(addTask);
  addTaskRef.current = addTask;

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
        e.preventDefault();
        submitRef.current();
        return;
      }
      if (e.key === "Escape") return setShowKeys(false);
      if (e.metaKey || e.ctrlKey || e.altKey || isTyping(e.target)) return;
      if (e.key === "/") {
        e.preventDefault();
        searchRef.current?.focus();
      } else if (e.key === "?") {
        e.preventDefault();
        setShowKeys(true);
      } else if (e.key === "n" || e.key === "N") {
        e.preventDefault();
        addTaskRef.current();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  /* ----- task actions ----- */
  const handleRemove = (id) => {
    const undo = removeItem(id);
    toast("Task deleted", { action: { label: "Undo", run: undo } });
  };

  const snooze = (taskId, kind) => {
    let until;
    if (kind === "tomorrow") {
      const d = new Date();
      d.setDate(d.getDate() + 1);
      d.setHours(9, 0, 0, 0);
      until = d.getTime();
    } else until = Date.now() + kind * MINUTE;
    updateItem(taskId, { notified: false, snoozedUntil: until });
    setAlerts((a) => a.filter((x) => x.taskId !== taskId));
    toast("Snoozed");
  };

  /* ----- summary actions ----- */
  const itemsBySummary = useMemo(() => {
    const m = new Map();
    for (const it of data.items) if (it.summaryId) m.set(it.summaryId, [...(m.get(it.summaryId) || []), it]);
    return m;
  }, [data.items]);

  const summaryIndex = useMemo(
    () =>
      new Map(
        data.summaries.map((s) => [
          s.id,
          "From " + new Date(s.createdAt).toLocaleDateString([], { month: "short", day: "numeric" }),
        ])
      ),
    [data.summaries]
  );

  const copySummary = async (s) => {
    const ok = await copyText(summaryToMarkdown(s, itemsBySummary.get(s.id) || []));
    toast(ok ? "Copied summary as Markdown" : "Couldn't copy to clipboard", { tone: ok ? "default" : "error" });
  };

  const deleteSummary = (s) => {
    const undo = removeSummary(s.id);
    toast("Summary deleted (tasks kept)", { action: { label: "Undo", run: undo } });
  };

  const resummarize = (s) =>
    run({
      text: s.source,
      summaryId: s.id,
      options: s.options || { length: settings.length, language: settings.language },
    });

  /* ----- data in/out ----- */
  const exportJson = () => {
    downloadFile(
      `what-did-i-miss-${new Date().toISOString().slice(0, 10)}.json`,
      JSON.stringify({ app: "what-did-i-miss", version: 2, exportedAt: new Date().toISOString(), ...data }, null, 2),
      "application/json"
    );
    toast("Exported your data");
  };

  const importFile = async (file) => {
    try {
      const raw = JSON.parse(await file.text());
      if (!raw || (!Array.isArray(raw.items) && !Array.isArray(raw.summaries))) throw new Error("bad shape");
      const n = importData(raw, "merge");
      toast(`Imported ${n.items} task${n.items === 1 ? "" : "s"} and ${n.summaries} summar${n.summaries === 1 ? "y" : "ies"}`);
    } catch {
      toast("That file isn't a valid export.", { tone: "error" });
    }
  };

  const exportIcs = () => {
    const { text: ics, count } = itemsToIcs(data.items);
    if (!count) return toast("No open tasks with deadlines to export");
    downloadFile("action-items.ics", ics, "text/calendar");
    toast(`Calendar file with ${count} event${count === 1 ? "" : "s"} downloaded`);
  };

  const install = async () => {
    if (!installEvt) return;
    installEvt.prompt();
    await installEvt.userChoice?.catch(() => {});
    setInstallEvt(null);
  };

  /* ----- derived ----- */
  const stats = useMemo(() => {
    const open = data.items.filter((i) => !i.done);
    return {
      open: open.length,
      today: open.filter((i) => isToday(toTime(i.deadline), now)).length,
      overdue: open.filter((i) => toTime(i.deadline) != null && toTime(i.deadline) < now).length,
      done: data.items.length - open.length,
      total: data.items.length,
    };
  }, [data.items, now]);

  const visibleAlerts = alerts
    .map((a) => ({ ...a, item: data.items.find((i) => i.id === a.taskId) }))
    .filter((a) => a.item && !a.item.done);

  const q = query.trim().toLowerCase();
  const summaries = q
    ? data.summaries.filter((s) =>
        [s.summary, ...s.decisions, ...s.openQuestions, s.source].join(" ").toLowerCase().includes(q)
      )
    : data.summaries;

  return (
    <div className="shell">
      <a className="skip" href="#main">
        Skip to content
      </a>
      <Header
        theme={theme.effective}
        onToggleTheme={theme.toggle}
        onShortcuts={() => setShowKeys(true)}
        leadMinutes={settings.leadMinutes}
        onLeadMinutes={(m) => setSettings((s) => ({ ...s, leadMinutes: m }))}
        onExportJson={exportJson}
        onImportFile={importFile}
        onIcs={exportIcs}
        canInstall={!!installEvt}
        onInstall={install}
      />

      <main id="main" className="wrap">
        {perm === "default" && (
          <button className="banner-btn" onClick={async () => setPerm(await requestPermission())}>
            <Icon name="bell" size={17} /> Enable deadline notifications
          </button>
        )}
        {perm === "denied" && (
          <p className="muted note">Notifications are blocked in this browser. Deadline alerts will show on the page instead.</p>
        )}

        {visibleAlerts.map(({ taskId, item }) => (
          <div className="alert" role="alert" key={taskId}>
            <div className="alert-text">
              <Icon name="clock" size={18} />
              <div>
                <strong>{item.task}</strong>
                <span className="muted"> · {deadlineInfo(item.deadline, leadMs, now).text}</span>
              </div>
            </div>
            <div className="alert-actions">
              <button className="ghost" onClick={() => snooze(taskId, 15)}>15 min</button>
              <button className="ghost" onClick={() => snooze(taskId, 60)}>1 hr</button>
              <button className="ghost" onClick={() => snooze(taskId, "tomorrow")}>Tomorrow</button>
              <button className="icon-btn sm" aria-label="Dismiss alert" onClick={() => setAlerts((a) => a.filter((x) => x.taskId !== taskId))}>
                <Icon name="x" size={16} />
              </button>
            </div>
          </div>
        ))}

        <Dashboard stats={stats} />

        <Composer
          text={text}
          setText={setText}
          options={{ length: settings.length, language: settings.language }}
          setOptions={(patch) => setSettings((s) => ({ ...s, ...patch }))}
          loading={loading && !busyId}
          onSubmit={submit}
          error={error}
          onRetry={() => lastReq.current && run(lastReq.current)}
          textareaRef={textareaRef}
          onNotice={toast}
        />

        <div className="search">
          <Icon name="search" size={18} />
          <input
            ref={searchRef}
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search tasks and summaries"
            aria-label="Search tasks and summaries"
          />
          {!query && <kbd>/</kbd>}
        </div>

        <div className="columns">
          <TaskList
            items={data.items}
            query={query}
            leadMs={leadMs}
            now={now}
            onUpdate={updateItem}
            onRemove={handleRemove}
            onAdd={addTask}
            newId={newId}
            onEditEnd={() => setNewId(null)}
            summaryIndex={summaryIndex}
          />

          <section className="panel" aria-labelledby="sum-h">
            <div className="panel-head">
              <h2 id="sum-h">Summaries</h2>
            </div>
            {loading && !busyId && <SummarySkeleton />}
            {summaries.length === 0 && !(loading && !busyId) ? (
              data.summaries.length === 0 ? (
                <EmptyState icon="file" title="No summaries yet" hint="Paste a thread above and hit Summarize. Your history will live here." />
              ) : (
                <EmptyState icon="search" title="No summaries match" hint="Try a different search." />
              )
            ) : (
              summaries.map((s, i) => (
                <SummaryCard
                  key={s.id}
                  s={s}
                  items={itemsBySummary.get(s.id) || []}
                  defaultOpen={i === 0 && !q}
                  busy={busyId === s.id || loading}
                  onCopy={copySummary}
                  onResummarize={resummarize}
                  onDelete={deleteSummary}
                />
              ))
            )}
          </section>
        </div>

        <footer className="foot muted">Your tasks and summaries are stored only in this browser.</footer>
      </main>

      {showKeys && <ShortcutsDialog onClose={() => setShowKeys(false)} />}
      <Toasts toasts={toasts} onDismiss={dismiss} />
    </div>
  );
}
