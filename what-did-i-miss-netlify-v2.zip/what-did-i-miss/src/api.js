import { uid } from "./storage";

const pad = (n) => String(n).padStart(2, "0");

function normalizeDeadline(v) {
  if (typeof v !== "string") return null;
  const s = v.trim();
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(s)) return s.slice(0, 16);
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s + "T09:00";
  return null; // "null", "none", free text, etc.
}

const list = (v) =>
  (Array.isArray(v) ? v : []).filter((x) => typeof x === "string" && x.trim()).map((x) => x.trim());

/**
 * @param {string} text
 * @param {{length?: "brief"|"detailed", language?: string}} [options]
 */
export async function summarize(text, options = {}) {
  const d = new Date();
  const nowLocal = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`;
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  let res;
  try {
    res = await fetch("/api/summarize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text,
        nowLocal,
        timeZone,
        length: options.length || "brief",
        language: options.language || "English",
      }),
    });
  } catch {
    throw new Error("Could not reach the server. Check your connection.");
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(
      data.error ||
        `Request failed (HTTP ${res.status}). If you are running "npm run dev", the API is not available there; use "npx netlify dev" or the deployed site.`
    );
  }

  const created = new Date().toISOString();
  const items = (Array.isArray(data.actionItems) ? data.actionItems : []).map((i) => ({
    id: uid(),
    task: String(i?.task || "Untitled task"),
    deadline: normalizeDeadline(i?.deadline),
    priority: ["high", "medium", "low"].includes(i?.priority) ? i.priority : "medium",
    owner: i?.owner && i.owner !== "null" ? String(i.owner) : null,
    done: false,
    notified: false,
    snoozedUntil: null,
    origin: "ai",
    createdAt: created,
  }));

  return {
    summary: String(data.summary || ""),
    decisions: list(data.decisions),
    openQuestions: list(data.openQuestions),
    urgency: ["low", "medium", "high"].includes(data.urgency) ? data.urgency : "medium",
    sentiment: ["positive", "neutral", "tense", "negative"].includes(data.sentiment)
      ? data.sentiment
      : "neutral",
    items,
  };
}
