import { useRef, useState } from "react";
import Icon from "./Icons";

export const MAX_CHARS = 20000;
const LANGS = ["English", "Español", "Français", "Deutsch", "Português", "Italiano", "हिन्दी", "日本語", "中文", "한국어", "العربية"];
const TEXT_EXT = /\.(txt|md|markdown|eml|log|csv|text)$/i;

export default function Composer({
  text,
  setText,
  options,
  setOptions,
  loading,
  onSubmit,
  error,
  onRetry,
  textareaRef,
  onNotice,
}) {
  const [dragging, setDragging] = useState(false);
  const fileRef = useRef(null);
  const over = text.length > MAX_CHARS;
  const canSubmit = !!text.trim() && !loading && !over;

  async function readFile(file) {
    if (!file) return;
    if (!(file.type.startsWith("text/") || TEXT_EXT.test(file.name))) {
      onNotice("Please drop a text file (.txt, .md, .eml).");
      return;
    }
    try {
      const content = await file.text();
      setText((prev) => (prev.trim() ? prev.replace(/\s+$/, "") + "\n\n" + content : content));
      onNotice(`Loaded ${file.name}`);
    } catch {
      onNotice("Couldn't read that file.");
    }
  }

  return (
    <section
      className={`card composer ${dragging ? "dragging" : ""}`}
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={(e) => {
        if (!e.currentTarget.contains(e.relatedTarget)) setDragging(false);
      }}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        readFile(e.dataTransfer.files?.[0]);
      }}
      aria-label="Conversation input"
    >
      <div className="composer-top">
        <label htmlFor="source" className="section-title">
          What did you miss?
        </label>
        <button type="button" className="link-btn" onClick={() => fileRef.current?.click()}>
          <Icon name="upload" size={15} /> Upload .txt
        </button>
        <input
          ref={fileRef}
          type="file"
          hidden
          accept=".txt,.md,.markdown,.eml,.log,.csv,text/*"
          onChange={(e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            readFile(f);
          }}
        />
      </div>

      <div className="textarea-wrap">
        <textarea
          id="source"
          ref={textareaRef}
          rows={8}
          placeholder="Paste a conversation, email thread, or meeting notes… or drop a text file here."
          value={text}
          onChange={(e) => setText(e.target.value)}
          aria-describedby="char-count"
        />
        {dragging && (
          <div className="drop-hint" aria-hidden="true">
            <Icon name="upload" size={28} />
            <span>Drop to load text</span>
          </div>
        )}
      </div>

      <div className="composer-bottom">
        <div className="options">
          <div className="segmented" role="radiogroup" aria-label="Summary length">
            {[
              ["brief", "Brief"],
              ["detailed", "Detailed"],
            ].map(([v, l]) => (
              <button
                key={v}
                type="button"
                role="radio"
                aria-checked={options.length === v}
                className={options.length === v ? "on" : ""}
                onClick={() => setOptions({ length: v })}
              >
                {l}
              </button>
            ))}
          </div>
          <label className="lang">
            <span className="sr-only">Summary language</span>
            <input
              list="langs"
              value={options.language}
              maxLength={40}
              onChange={(e) => setOptions({ language: e.target.value })}
              onBlur={(e) => !e.target.value.trim() && setOptions({ language: "English" })}
              aria-label="Summary language"
              placeholder="Language"
            />
            <datalist id="langs">
              {LANGS.map((l) => (
                <option key={l} value={l} />
              ))}
            </datalist>
          </label>
        </div>

        <div className="submit-row">
          <span id="char-count" className={`counter ${over ? "over" : text.length > MAX_CHARS * 0.9 ? "near" : ""}`}>
            {text.length.toLocaleString()} / {MAX_CHARS.toLocaleString()}
          </span>
          <button className="primary" onClick={onSubmit} disabled={!canSubmit}>
            <Icon name="sparkle" size={17} />
            {loading ? "Summarizing…" : "Summarize"}
            {!loading && <kbd>⌘↵</kbd>}
          </button>
        </div>
      </div>

      {over && <p className="error" role="alert">Too long: trim {(text.length - MAX_CHARS).toLocaleString()} characters to continue.</p>}
      {error && (
        <div className="error-box" role="alert">
          <span>{error}</span>
          <button className="ghost" onClick={onRetry} disabled={loading}>
            <Icon name="refresh" size={15} /> Try again
          </button>
        </div>
      )}
    </section>
  );
}
