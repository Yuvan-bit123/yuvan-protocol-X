import Icon from "./Icons";

function Ring({ pct }) {
  const r = 22;
  const c = 2 * Math.PI * r;
  return (
    <svg className="ring" width="56" height="56" viewBox="0 0 56 56" role="img" aria-label={`${pct}% complete`}>
      <circle cx="28" cy="28" r={r} className="ring-track" />
      <circle
        cx="28"
        cy="28"
        r={r}
        className="ring-fill"
        strokeDasharray={c}
        strokeDashoffset={c * (1 - pct / 100)}
        transform="rotate(-90 28 28)"
      />
      <text x="28" y="32" textAnchor="middle" className="ring-text">
        {pct}%
      </text>
    </svg>
  );
}

export default function Dashboard({ stats }) {
  const { open, today, overdue, done, total } = stats;
  const pct = total ? Math.round((done / total) * 100) : 0;
  const tiles = [
    { label: "Open", value: open, icon: "inbox", tone: "" },
    { label: "Due today", value: today, icon: "clock", tone: today ? "warn" : "" },
    { label: "Overdue", value: overdue, icon: "flag", tone: overdue ? "danger" : "" },
  ];
  return (
    <section className="dash" aria-label="Task overview">
      {tiles.map((t) => (
        <div key={t.label} className={`stat ${t.tone}`}>
          <Icon name={t.icon} size={16} />
          <span className="stat-value">{t.value}</span>
          <span className="stat-label">{t.label}</span>
        </div>
      ))}
      <div className="stat progress">
        <Ring pct={pct} />
        <div>
          <span className="stat-value small">
            {done}/{total}
          </span>
          <span className="stat-label">Completed</span>
        </div>
      </div>
    </section>
  );
}
