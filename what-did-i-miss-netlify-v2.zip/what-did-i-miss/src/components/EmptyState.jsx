import Icon from "./Icons";

export default function EmptyState({ icon = "inbox", title, hint, children }) {
  return (
    <div className="empty">
      <div className="empty-art" aria-hidden="true">
        <span className="blob" />
        <Icon name={icon} size={30} />
      </div>
      <p className="empty-title">{title}</p>
      {hint && <p className="muted">{hint}</p>}
      {children}
    </div>
  );
}
