import { useEffect, useRef, useState } from "react";
import Icon from "./Icons";

const LEADS = [
  [15, "15 minutes"],
  [30, "30 minutes"],
  [60, "1 hour"],
  [120, "2 hours"],
  [1440, "1 day"],
];

export default function Header({
  theme,
  onToggleTheme,
  onShortcuts,
  leadMinutes,
  onLeadMinutes,
  onExportJson,
  onImportFile,
  onIcs,
  canInstall,
  onInstall,
}) {
  const [open, setOpen] = useState(false);
  const wrap = useRef(null);
  const fileRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e) => wrap.current && !wrap.current.contains(e.target) && setOpen(false);
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <header className="header">
      <div className="brand">
        <span className="logo" aria-hidden="true">
          <Icon name="logo" size={22} />
        </span>
        <div>
          <h1>What Did I Miss?</h1>
          <p className="tagline">Paste the thread. Get the story, the decisions and the to-dos.</p>
        </div>
      </div>

      <div className="header-actions" ref={wrap}>
        <button className="icon-btn" onClick={onShortcuts} aria-label="Keyboard shortcuts" title="Keyboard shortcuts (?)">
          <Icon name="keyboard" />
        </button>
        <button
          className="icon-btn"
          onClick={onToggleTheme}
          aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
          title={theme === "dark" ? "Light theme" : "Dark theme"}
        >
          <Icon name={theme === "dark" ? "sun" : "moon"} />
        </button>
        <button
          className="icon-btn"
          onClick={() => setOpen((o) => !o)}
          aria-haspopup="menu"
          aria-expanded={open}
          aria-label="Settings and data"
          title="Settings and data"
        >
          <Icon name="menu" />
        </button>

        {open && (
          <div className="popover" role="menu" aria-label="Settings and data">
            <label className="field">
              <span className="field-label">
                <Icon name="bell" size={15} /> Remind me before a deadline
              </span>
              <select value={leadMinutes} onChange={(e) => onLeadMinutes(Number(e.target.value))}>
                {LEADS.map(([v, l]) => (
                  <option key={v} value={v}>
                    {l}
                  </option>
                ))}
              </select>
            </label>
            <div className="divider" />
            <button className="menu-item" role="menuitem" onClick={() => { onIcs(); setOpen(false); }}>
              <Icon name="calendar" size={16} /> Download tasks as calendar (.ics)
            </button>
            <button className="menu-item" role="menuitem" onClick={() => { onExportJson(); setOpen(false); }}>
              <Icon name="download" size={16} /> Export all data (JSON)
            </button>
            <button className="menu-item" role="menuitem" onClick={() => fileRef.current?.click()}>
              <Icon name="upload" size={16} /> Import data (JSON)
            </button>
            {canInstall && (
              <button className="menu-item" role="menuitem" onClick={() => { onInstall(); setOpen(false); }}>
                <Icon name="sparkle" size={16} /> Install app
              </button>
            )}
            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              hidden
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = "";
                if (f) {
                  onImportFile(f);
                  setOpen(false);
                }
              }}
            />
          </div>
        )}
      </div>
    </header>
  );
}
