import { useEffect, useRef } from "react";
import Icon from "./Icons";

const ROWS = [
  [["Ctrl / ⌘", "Enter"], "Summarize the pasted text"],
  [["/"], "Search tasks and summaries"],
  [["N"], "Add a task"],
  [["?"], "Show this help"],
  [["Esc"], "Close dialogs and menus"],
];

export default function ShortcutsDialog({ onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    ref.current?.focus();
  }, []);
  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="dialog" role="dialog" aria-modal="true" aria-labelledby="sc-title" tabIndex={-1} ref={ref}>
        <div className="dialog-head">
          <h2 id="sc-title">Keyboard shortcuts</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            <Icon name="x" />
          </button>
        </div>
        <ul className="sc-list">
          {ROWS.map(([keys, label]) => (
            <li key={label}>
              <span>{label}</span>
              <span className="keys">
                {keys.map((k) => (
                  <kbd key={k}>{k}</kbd>
                ))}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
