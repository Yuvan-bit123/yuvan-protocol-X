import { useState } from "react";
import Icon from "./Icons";
import { relativeDay } from "../utils";

const TONE = { positive: "Positive", neutral: "Neutral", tense: "Tense", negative: "Negative" };

export default function SummaryCard({ s, items, defaultOpen, busy, onCopy, onResummarize, onDelete }) {
  const [open, setOpen] = useState(!!defaultOpen);
  const [showSource, setShowSource] = useState(false);
  const bodyId = `sum-${s.id}`;
  const openTasks = items.filter((i) => !i.done).length;
  const first = s.summary.split(/(?<=[.!?])\s/)[0] || "Summary";

  return (
    <article className="card summary">
      <button className="summary-head" aria-expanded={open} aria-controls={bodyId} onClick={() => setOpen((o) => !o)}>
        <div className="summary-head-text">
          <div className="summary-meta">
            <span className="muted">{relativeDay(s.createdAt)}</span>
            {s.urgency && <span className={`tag urg-${s.urgency}`}>{s.urgency} urgency</span>}
            {s.sentiment && <span className={`tag tone-${s.sentiment}`}>{TONE[s.sentiment]}</span>}
          </div>
          {!open && <p className="summary-peek">{first}</p>}
        </div>
        <Icon name="chevron" className={`chev ${open ? "open" : ""}`} />
      </button>

      {open && (
        <div id={bodyId} className="summary-body">
          <p className="summary-text">{s.summary || "No summary was returned."}</p>

          {s.decisions.length > 0 && (
            <div className="block">
              <h3>
                <Icon name="gavel" size={15} /> Key decisions
              </h3>
              <ul>
                {s.decisions.map((d, i) => (
                  <li key={i}>{d}</li>
                ))}
              </ul>
            </div>
          )}

          {s.openQuestions.length > 0 && (
            <div className="block">
              <h3>
                <Icon name="question" size={15} /> Open questions
              </h3>
              <ul>
                {s.openQuestions.map((q, i) => (
                  <li key={i}>{q}</li>
                ))}
              </ul>
            </div>
          )}

          {items.length > 0 && (
            <div className="block">
              <h3>
                <Icon name="check" size={15} /> Linked tasks <span className="muted">· {openTasks} open of {items.length}</span>
              </h3>
              <ul className="linked">
                {items.map((it) => (
                  <li key={it.id} className={it.done ? "is-done" : ""}>
                    {it.task}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {s.source && (
            <div className="block">
              <button className="link-btn" onClick={() => setShowSource((v) => !v)} aria-expanded={showSource}>
                <Icon name="file" size={15} /> {showSource ? "Hide" : "Show"} original text
              </button>
              {showSource && <pre className="source">{s.source}</pre>}
            </div>
          )}

          <div className="summary-actions">
            <button className="ghost" onClick={() => onCopy(s)}>
              <Icon name="copy" size={15} /> Copy as Markdown
            </button>
            {s.source && (
              <button className="ghost" onClick={() => onResummarize(s)} disabled={busy}>
                <Icon name="refresh" size={15} /> Re-summarize
              </button>
            )}
            <span className="spacer" />
            <button className="ghost danger" onClick={() => onDelete(s)}>
              <Icon name="trash" size={15} /> Delete
            </button>
          </div>
        </div>
      )}
    </article>
  );
}

export function SummarySkeleton() {
  return (
    <div className="card summary skeleton" aria-busy="true" aria-label="Summarizing">
      <div className="sk sk-line short" />
      <div className="sk sk-line" />
      <div className="sk sk-line" />
      <div className="sk sk-line mid" />
      <div className="sk-row">
        <div className="sk sk-pill" />
        <div className="sk sk-pill" />
        <div className="sk sk-pill" />
      </div>
    </div>
  );
}
