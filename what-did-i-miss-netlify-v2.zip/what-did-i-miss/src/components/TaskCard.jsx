import { useEffect, useRef, useState } from "react";
import Icon from "./Icons";
import { NEXT_PRIORITY, deadlineInfo, toInput } from "../utils";

export default function TaskCard({ item, leadMs, now, onUpdate, onRemove, autoEdit, onEditEnd, summaryLabel }) {
  const [editing, setEditing] = useState(!!autoEdit);
  const [draft, setDraft] = useState({ task: item.task, owner: item.owner || "", deadline: toInput(item.deadline) });
  const taskRef = useRef(null);
  const info = deadlineInfo(item.deadline, leadMs, now);

  useEffect(() => {
    if (editing) {
      taskRef.current?.focus();
      taskRef.current?.select();
    }
  }, [editing]);

  const startEdit = () => {
    setDraft({ task: item.task, owner: item.owner || "", deadline: toInput(item.deadline) });
    setEditing(true);
  };

  const finish = () => {
    setEditing(false);
    onEditEnd?.();
  };

  const commit = (e) => {
    e?.preventDefault();
    const task = draft.task.trim();
    if (!task) return;
    const deadline = draft.deadline || null;
    onUpdate(item.id, {
      task,
      owner: draft.owner.trim() || null,
      deadline,
      notified: deadline !== item.deadline ? false : item.notified,
      snoozedUntil: deadline !== item.deadline ? null : item.snoozedUntil,
    });
    finish();
  };

  if (editing) {
    return (
      <form className={`task editing pri-${item.priority}`} onSubmit={commit} onKeyDown={(e) => e.key === "Escape" && finish()}>
        <div className="edit-grid">
          <label className="field wide">
            <span className="field-label">Task</span>
            <input ref={taskRef} value={draft.task} onChange={(e) => setDraft({ ...draft, task: e.target.value })} maxLength={300} />
          </label>
          <label className="field">
            <span className="field-label">Owner</span>
            <input value={draft.owner} placeholder="Anyone" onChange={(e) => setDraft({ ...draft, owner: e.target.value })} maxLength={60} />
          </label>
          <label className="field">
            <span className="field-label">Deadline</span>
            <input type="datetime-local" value={draft.deadline} onChange={(e) => setDraft({ ...draft, deadline: e.target.value })} />
          </label>
        </div>
        <div className="edit-actions">
          {draft.deadline && (
            <button type="button" className="ghost" onClick={() => setDraft({ ...draft, deadline: "" })}>
              Clear deadline
            </button>
          )}
          <span className="spacer" />
          <button type="button" className="ghost" onClick={finish}>
            Cancel
          </button>
          <button type="submit" className="primary small" disabled={!draft.task.trim()}>
            Save
          </button>
        </div>
      </form>
    );
  }

  return (
    <article className={`task pri-${item.priority} ${item.done ? "done" : ""} ${item.done ? "" : `dl-${info.state}`}`}>
      <input
        type="checkbox"
        className="check"
        aria-label={`Mark "${item.task}" ${item.done ? "not done" : "done"}`}
        checked={item.done}
        onChange={(e) => onUpdate(item.id, { done: e.target.checked })}
      />
      <div className="task-body">
        <p className="task-title">{item.task}</p>
        <div className="meta">
          <button
            className={`pill pri-pill ${item.priority}`}
            onClick={() => onUpdate(item.id, { priority: NEXT_PRIORITY[item.priority] })}
            aria-label={`Priority ${item.priority}. Press to change.`}
            title="Click to change priority"
          >
            <Icon name="flag" size={13} /> {item.priority}
          </button>
          <button className={`pill dl-pill ${item.done ? "none" : info.state}`} onClick={startEdit} title={info.title}>
            <Icon name={info.state === "overdue" ? "flag" : "clock"} size={13} /> {info.text}
          </button>
          {item.owner && <span className="pill owner">@{item.owner}</span>}
          {summaryLabel && <span className="pill from" title="Came from a summary">{summaryLabel}</span>}
        </div>
      </div>
      <div className="task-actions">
        <button className="icon-btn sm" onClick={startEdit} aria-label="Edit task" title="Edit">
          <Icon name="edit" size={16} />
        </button>
        <button className="icon-btn sm danger" onClick={() => onRemove(item.id)} aria-label="Delete task" title="Delete">
          <Icon name="trash" size={16} />
        </button>
      </div>
    </article>
  );
}
