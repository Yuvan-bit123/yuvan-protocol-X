import { useMemo, useState } from "react";
import Icon from "./Icons";
import EmptyState from "./EmptyState";
import TaskCard from "./TaskCard";
import { PRIORITY_ORDER, isToday, toTime } from "../utils";

const FILTERS = [
  ["all", "All"],
  ["today", "Today"],
  ["overdue", "Overdue"],
  ["high", "High priority"],
  ["done", "Done"],
];

const SORTS = [
  ["priority", "Priority"],
  ["deadline", "Deadline"],
  ["newest", "Newest"],
];

export default function TaskList({ items, query, leadMs, now, onUpdate, onRemove, onAdd, newId, onEditEnd, summaryIndex }) {
  const [filter, setFilter] = useState("all");
  const [owner, setOwner] = useState("");
  const [sort, setSort] = useState("priority");

  const owners = useMemo(() => [...new Set(items.map((i) => i.owner).filter(Boolean))].sort(), [items]);

  const counts = useMemo(() => {
    const open = items.filter((i) => !i.done);
    return {
      all: items.length,
      today: open.filter((i) => isToday(toTime(i.deadline), now)).length,
      overdue: open.filter((i) => toTime(i.deadline) != null && toTime(i.deadline) < now).length,
      high: open.filter((i) => i.priority === "high").length,
      done: items.length - open.length,
    };
  }, [items, now]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = items.filter((it) => {
      const t = toTime(it.deadline);
      if (filter === "today" && (it.done || !isToday(t, now))) return false;
      if (filter === "overdue" && (it.done || t == null || t >= now)) return false;
      if (filter === "high" && (it.done || it.priority !== "high")) return false;
      if (filter === "done" && !it.done) return false;
      if (owner && it.owner !== owner) return false;
      if (q && !`${it.task} ${it.owner || ""}`.toLowerCase().includes(q)) return false;
      return true;
    });
    const byDeadline = (a, b) => (toTime(a.deadline) ?? Infinity) - (toTime(b.deadline) ?? Infinity);
    const byPriority = (a, b) => PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority];
    const byNewest = (a, b) => (b.createdAt || "").localeCompare(a.createdAt || "");
    const cmp = { priority: (a, b) => byPriority(a, b) || byDeadline(a, b), deadline: (a, b) => byDeadline(a, b) || byPriority(a, b), newest: byNewest }[sort];
    // Stable sort keeps ties in insertion order (newest first), done tasks sink to the bottom.
    const sorted = [...list].sort((a, b) => Number(a.done) - Number(b.done) || cmp(a, b));
    // A task being created is pinned to the top so it never scrolls out of view.
    const fresh = items.find((i) => i.id === newId);
    return fresh ? [fresh, ...sorted.filter((i) => i.id !== newId)] : sorted;
  }, [items, filter, owner, sort, query, now, newId]);

  return (
    <section className="panel" aria-labelledby="tasks-h">
      <div className="panel-head">
        <h2 id="tasks-h">Action items</h2>
        <button className="ghost" onClick={onAdd}>
          <Icon name="plus" size={16} /> Add task
        </button>
      </div>

      <div className="toolbar">
        <div className="chips" role="tablist" aria-label="Filter tasks">
          {FILTERS.map(([v, l]) => (
            <button
              key={v}
              role="tab"
              aria-selected={filter === v}
              className={`chip ${filter === v ? "on" : ""}`}
              onClick={() => setFilter(v)}
            >
              {l} <span className="count">{counts[v]}</span>
            </button>
          ))}
        </div>
        <div className="selects">
          {owners.length > 0 && (
            <label className="mini-select">
              <span className="sr-only">Filter by owner</span>
              <select value={owner} onChange={(e) => setOwner(e.target.value)} aria-label="Filter by owner">
                <option value="">Everyone</option>
                {owners.map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </select>
            </label>
          )}
          <label className="mini-select">
            <span className="sr-only">Sort tasks</span>
            <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort tasks">
              {SORTS.map(([v, l]) => (
                <option key={v} value={v}>
                  Sort: {l}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>

      {items.length === 0 ? (
        <EmptyState icon="check" title="No action items yet" hint="Summarize a conversation and the to-dos land here, or add one yourself.">
          <button className="ghost" onClick={onAdd}>
            <Icon name="plus" size={16} /> Add a task
          </button>
        </EmptyState>
      ) : visible.length === 0 ? (
        <EmptyState icon="search" title="Nothing matches" hint="Try a different filter or clear the search." />
      ) : (
        <div className="task-list">
          {visible.map((it) => (
            <TaskCard
              key={it.id}
              item={it}
              leadMs={leadMs}
              now={now}
              onUpdate={onUpdate}
              onRemove={onRemove}
              autoEdit={it.id === newId}
              onEditEnd={onEditEnd}
              summaryLabel={it.summaryId ? summaryIndex.get(it.summaryId) : null}
            />
          ))}
        </div>
      )}
    </section>
  );
}
