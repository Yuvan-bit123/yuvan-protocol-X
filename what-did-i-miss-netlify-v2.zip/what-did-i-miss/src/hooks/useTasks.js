import { useCallback, useEffect, useRef, useState } from "react";
import { load, normalizeData, normalizeItem, normalizeSummary, save, uid } from "../storage";

/** All task + summary state and the actions that change it. */
export function useTasks() {
  const [data, setData] = useState(load);
  const dataRef = useRef(data);

  useEffect(() => {
    dataRef.current = data;
    save(data);
  }, [data]);

  const addResult = useCallback((result, source, options) => {
    const summaryId = uid();
    const summary = normalizeSummary({
      id: summaryId,
      createdAt: new Date().toISOString(),
      summary: result.summary,
      decisions: result.decisions,
      openQuestions: result.openQuestions,
      urgency: result.urgency,
      sentiment: result.sentiment,
      source,
      options,
    });
    setData((d) => ({
      summaries: [summary, ...d.summaries],
      items: [...result.items.map((i) => ({ ...i, summaryId })), ...d.items],
    }));
    return summaryId;
  }, []);

  /** Replace a summary's content and swap its untouched open AI tasks for the new ones. */
  const replaceResult = useCallback((summaryId, result, options) => {
    setData((d) => ({
      summaries: d.summaries.map((s) =>
        s.id === summaryId
          ? {
              ...s,
              summary: result.summary,
              decisions: result.decisions,
              openQuestions: result.openQuestions,
              urgency: result.urgency,
              sentiment: result.sentiment,
              options,
            }
          : s
      ),
      items: [
        ...result.items.map((i) => ({ ...i, summaryId })),
        ...d.items.filter((it) => !(it.summaryId === summaryId && it.origin === "ai" && !it.done)),
      ],
    }));
  }, []);

  const updateItem = useCallback(
    (id, patch) =>
      setData((d) => ({ ...d, items: d.items.map((it) => (it.id === id ? { ...it, ...patch } : it)) })),
    []
  );

  const addItem = useCallback((fields = {}) => {
    const item = normalizeItem({
      id: uid(),
      task: fields.task || "New task",
      priority: "medium",
      origin: "manual",
      createdAt: new Date().toISOString(),
      ...fields,
    });
    setData((d) => ({ ...d, items: [item, ...d.items] }));
    return item;
  }, []);

  /** Removes a task and returns a function that puts it back in the same position. */
  const removeItem = useCallback((id) => {
    const index = dataRef.current.items.findIndex((it) => it.id === id);
    if (index < 0) return () => {};
    const item = dataRef.current.items[index];
    setData((d) => ({ ...d, items: d.items.filter((it) => it.id !== id) }));
    return () =>
      setData((d) => {
        if (d.items.some((it) => it.id === id)) return d;
        const items = [...d.items];
        items.splice(Math.min(index, items.length), 0, item);
        return { ...d, items };
      });
  }, []);

  const removeSummary = useCallback((id) => {
    const index = dataRef.current.summaries.findIndex((s) => s.id === id);
    if (index < 0) return () => {};
    const summary = dataRef.current.summaries[index];
    setData((d) => ({ ...d, summaries: d.summaries.filter((s) => s.id !== id) }));
    return () =>
      setData((d) => {
        if (d.summaries.some((s) => s.id === id)) return d;
        const summaries = [...d.summaries];
        summaries.splice(Math.min(index, summaries.length), 0, summary);
        return { ...d, summaries };
      });
  }, []);

  const importData = useCallback((raw, mode = "merge") => {
    const incoming = normalizeData(raw);
    setData((d) => {
      if (mode === "replace") return incoming;
      const sIds = new Set(d.summaries.map((s) => s.id));
      const iIds = new Set(d.items.map((i) => i.id));
      return {
        summaries: [...d.summaries, ...incoming.summaries.filter((s) => !sIds.has(s.id))],
        items: [...d.items, ...incoming.items.filter((i) => !iIds.has(i.id))],
      };
    });
    return { summaries: incoming.summaries.length, items: incoming.items.length };
  }, []);

  return {
    data,
    dataRef,
    setData,
    addResult,
    replaceResult,
    updateItem,
    addItem,
    removeItem,
    removeSummary,
    importData,
  };
}
