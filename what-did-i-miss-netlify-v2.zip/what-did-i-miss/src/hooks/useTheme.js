import { useEffect, useState } from "react";

const systemDark = () =>
  typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches;

/** theme: "light" | "dark" | null (follow system). Applies data-theme on <html>. */
export function useTheme(theme, setTheme) {
  const [sysDark, setSysDark] = useState(systemDark);

  useEffect(() => {
    const mq = window.matchMedia?.("(prefers-color-scheme: dark)");
    if (!mq) return;
    const on = () => setSysDark(mq.matches);
    mq.addEventListener?.("change", on);
    return () => mq.removeEventListener?.("change", on);
  }, []);

  const effective = theme || (sysDark ? "dark" : "light");

  useEffect(() => {
    const root = document.documentElement;
    if (theme) root.setAttribute("data-theme", theme);
    else root.removeAttribute("data-theme");
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", effective === "dark" ? "#14120f" : "#f5f1ea");
  }, [theme, effective]);

  return { effective, toggle: () => setTheme(effective === "dark" ? "light" : "dark") };
}
