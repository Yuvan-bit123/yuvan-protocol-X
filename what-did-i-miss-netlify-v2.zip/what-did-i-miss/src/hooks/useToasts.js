import { useCallback, useRef, useState } from "react";

export function useToasts() {
  const [toasts, setToasts] = useState([]);
  const seq = useRef(0);

  const dismiss = useCallback((id) => setToasts((t) => t.filter((x) => x.id !== id)), []);

  /** toast("Saved") or toast("Deleted", { action: { label: "Undo", run: fn } }) */
  const toast = useCallback(
    (message, opts = {}) => {
      const id = ++seq.current;
      setToasts((t) => [...t.slice(-3), { id, message, action: opts.action || null, tone: opts.tone || "default" }]);
      setTimeout(() => dismiss(id), opts.action ? 7000 : 3200);
      return id;
    },
    [dismiss]
  );

  return { toasts, toast, dismiss };
}
