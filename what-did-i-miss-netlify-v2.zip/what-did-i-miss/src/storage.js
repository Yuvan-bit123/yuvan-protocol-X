// v2 keeps tasks/summaries (migrated from v1) plus separate settings.
const KEY_V1 = "wdim:data:v1";
const KEY = "wdim:data:v2";
const SETTINGS_KEY = "wdim:settings:v1";

export const DEFAULT_SETTINGS = {
  theme: null, // null = follow system, otherwise "light" | "dark"
  leadMinutes: 60,
  length: "brief",
  language: "English",
};

const arr = (v) => (Array.isArray(v) ? v : []);

export function normalizeItem(it) {
  return {
    id: it?.id || uid(),
    task: String(it?.task || "Untitled task"),
    owner: it?.owner ? String(it.owner) : null,
    deadline: typeof it?.deadline === "string" && it.deadline ? it.deadline : null,
    priority: ["high", "medium", "low"].includes(it?.priority) ? it.priority : "medium",
    done: !!it?.done,
    notified: !!it?.notified,
    snoozedUntil: typeof it?.snoozedUntil === "number" ? it.snoozedUntil : null,
    summaryId: it?.summaryId || null,
    origin: it?.origin === "manual" ? "manual" : "ai",
    createdAt: it?.createdAt || new Date(0).toISOString(),
  };
}

export function normalizeSummary(s) {
  return {
    id: s?.id || uid(),
    createdAt: s?.createdAt || new Date().toISOString(),
    summary: String(s?.summary || ""),
    decisions: arr(s?.decisions).map(String),
    openQuestions: arr(s?.openQuestions).map(String),
    urgency: ["low", "medium", "high"].includes(s?.urgency) ? s.urgency : null,
    sentiment: ["positive", "neutral", "tense", "negative"].includes(s?.sentiment) ? s.sentiment : null,
    source: typeof s?.source === "string" ? s.source : "",
    options: s?.options && typeof s.options === "object" ? s.options : null,
  };
}

export function normalizeData(d) {
  return {
    summaries: arr(d?.summaries).map(normalizeSummary),
    items: arr(d?.items).map(normalizeItem),
  };
}

function read(key) {
  try {
    return JSON.parse(localStorage.getItem(key));
  } catch {
    return null;
  }
}

export function load() {
  // Prefer v2; otherwise migrate v1 so nobody loses existing tasks.
  const v2 = read(KEY);
  if (v2) return normalizeData(v2);
  const v1 = read(KEY_V1);
  if (v1) {
    const migrated = normalizeData(v1);
    save(migrated);
    return migrated;
  }
  return { summaries: [], items: [] };
}

export function save(data) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* storage full or blocked; ignore */
  }
}

export function loadSettings() {
  const s = read(SETTINGS_KEY);
  return {
    theme: s?.theme === "light" || s?.theme === "dark" ? s.theme : null,
    leadMinutes: [15, 30, 60, 120, 1440].includes(s?.leadMinutes) ? s.leadMinutes : DEFAULT_SETTINGS.leadMinutes,
    length: s?.length === "detailed" ? "detailed" : "brief",
    language: typeof s?.language === "string" && s.language.trim() ? s.language.slice(0, 40) : "English",
  };
}

export function saveSettings(settings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    /* ignore */
  }
}

// crypto.randomUUID only exists on HTTPS/localhost, so keep a fallback.
export function uid() {
  try {
    if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  } catch {
    /* fall through */
  }
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}
