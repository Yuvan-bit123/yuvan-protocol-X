export const MINUTE = 60 * 1000;
export const HOUR = 60 * MINUTE;
export const DAY = 24 * HOUR;

export const PRIORITY_ORDER = { high: 0, medium: 1, low: 2 };
export const NEXT_PRIORITY = { high: "medium", medium: "low", low: "high" };

export const toInput = (v) => (v ? v.slice(0, 16) : "");

export function toTime(v) {
  if (!v) return null;
  const t = new Date(v).getTime();
  return Number.isNaN(t) ? null : t;
}

const pad = (n) => String(n).padStart(2, "0");
export const toLocalIso = (d) =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;

const startOfDay = (t) => {
  const d = new Date(t);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
};

export const isToday = (t, now = Date.now()) => t != null && startOfDay(t) === startOfDay(now);

function duration(ms) {
  const m = Math.max(1, Math.round(ms / MINUTE));
  if (m < 60) return `${m}m`;
  const h = Math.round(m / 60);
  if (h < 48) return `${h}h`;
  return `${Math.round(h / 24)}d`;
}

/** Friendly deadline label + a state used for styling: none | overdue | soon | today | ok */
export function deadlineInfo(deadline, leadMs = HOUR, now = Date.now()) {
  const t = toTime(deadline);
  if (t == null) return { text: "No deadline", state: "none", title: "Click to set a deadline" };
  const d = new Date(t);
  const title = d.toLocaleString([], { dateStyle: "full", timeStyle: "short" });
  const time = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  const diff = t - now;
  if (diff < 0) return { text: `Overdue by ${duration(-diff)}`, state: "overdue", title };
  const dayDiff = Math.round((startOfDay(t) - startOfDay(now)) / DAY);
  let text;
  if (dayDiff === 0) text = diff < HOUR ? `Due in ${duration(diff)}` : `Due today, ${time}`;
  else if (dayDiff === 1) text = `Due tomorrow, ${time}`;
  else if (dayDiff < 7) text = `Due ${d.toLocaleDateString([], { weekday: "long" })}, ${time}`;
  else text = `Due ${d.toLocaleDateString([], { month: "short", day: "numeric" })}, ${time}`;
  const state = diff <= leadMs ? "soon" : dayDiff === 0 ? "today" : "ok";
  return { text, state, title };
}

export function relativeDay(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

/* ---------- Exports ---------- */

export function summaryToMarkdown(s, items = []) {
  const lines = [`# Summary (${new Date(s.createdAt).toLocaleString()})`, "", s.summary || "_No summary_"];
  if (s.urgency || s.sentiment) {
    lines.push("", `**Urgency:** ${s.urgency || "n/a"} · **Tone:** ${s.sentiment || "n/a"}`);
  }
  if (s.decisions?.length) lines.push("", "## Key decisions", ...s.decisions.map((d) => `- ${d}`));
  if (s.openQuestions?.length) lines.push("", "## Open questions", ...s.openQuestions.map((q) => `- ${q}`));
  if (items.length) {
    lines.push(
      "",
      "## Action items",
      ...items.map((it) => {
        const bits = [`[${it.priority}]`];
        if (it.owner) bits.push(`@${it.owner}`);
        if (it.deadline) bits.push(`due ${new Date(it.deadline).toLocaleString()}`);
        return `- [${it.done ? "x" : " "}] ${it.task} (${bits.join(", ")})`;
      })
    );
  }
  return lines.join("\n") + "\n";
}

const icsEscape = (s) =>
  String(s).replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");

const icsStamp = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${pad(d.getHours())}${pad(d.getMinutes())}00`;
};

/** Builds a calendar file with a 30-minute event (and 15 min alarm) for each open task with a deadline. */
export function itemsToIcs(items) {
  const withDeadline = items.filter((it) => !it.done && toTime(it.deadline) != null);
  const now = new Date();
  const stamp = `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}T${pad(
    now.getUTCHours()
  )}${pad(now.getUTCMinutes())}${pad(now.getUTCSeconds())}Z`;
  const out = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//What Did I Miss//EN", "CALSCALE:GREGORIAN"];
  for (const it of withDeadline) {
    const start = toTime(it.deadline);
    out.push(
      "BEGIN:VEVENT",
      `UID:${it.id}@what-did-i-miss`,
      `DTSTAMP:${stamp}`,
      `DTSTART:${icsStamp(start)}`,
      `DTEND:${icsStamp(start + 30 * MINUTE)}`,
      `SUMMARY:${icsEscape(it.task)}`,
      `DESCRIPTION:${icsEscape(`Priority: ${it.priority}${it.owner ? `\nOwner: ${it.owner}` : ""}`)}`,
      "BEGIN:VALARM",
      "ACTION:DISPLAY",
      "DESCRIPTION:Task due",
      "TRIGGER:-PT15M",
      "END:VALARM",
      "END:VEVENT"
    );
  }
  out.push("END:VCALENDAR");
  return { text: out.join("\r\n") + "\r\n", count: withDeadline.length };
}

export function downloadFile(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}
